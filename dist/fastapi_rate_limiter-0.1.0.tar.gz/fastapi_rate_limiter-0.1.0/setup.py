from setuptools import setup, find_packages

setup(
    name="fastapi-rate-limiter",     
    version="0.1.0",
    description="A simple rate limiter for FastAPI",
    author="Awais",
    author_email="ahmadawaisgithub@gmail.com",
    packages=find_packages(),
    install_requires=["fastapi"],  
    python_requires=">=3.8",
)
